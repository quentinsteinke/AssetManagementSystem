from app import app
import os
from flask import render_template


@app.route('/')
def index():
    print(os.getcwd())
    return render_template('index.html')
